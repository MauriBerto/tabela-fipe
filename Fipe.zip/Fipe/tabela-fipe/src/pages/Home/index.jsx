import './style.css';
import { useState } from 'react';

function Home() {
  const [veiculos, setVeiculos] = useState([]); // Estado para armazenar veículos encontrados
  const [codigoFipe, setCodigoFipe] = useState(''); // Estado para armazenar o código FIPE pesquisado
  const [veiculoDetalhes, setVeiculoDetalhes] = useState(null); // Estado para armazenar os detalhes do veículo

  // Função para buscar os detalhes do veículo usando o código FIPE
  const fetchVeiculoDetalhes = async () => {
    if (!codigoFipe) return; // Verifica se o código FIPE foi informado

    try {
      // Faz a requisição à API com o código FIPE
      const response = await fetch(`https://brasilapi.com.br/api/fipe/preco/v1/${codigoFipe}`);
      const data = await response.json();

      if (response.ok && data.length > 0) {
        // Assume que o primeiro resultado é relevante e atualiza o estado com os detalhes do veículo
        setVeiculoDetalhes(data[0]);
      } else {
        alert('Nenhum veículo encontrado para o código informado.');
        setVeiculoDetalhes(null); // Limpa os detalhes do veículo se não houver resultados
      }
    } catch (error) {
      console.error('Erro ao buscar dados do veículo:', error);
      alert('Erro ao buscar os detalhes do veículo.');
      setVeiculoDetalhes(null);
    }
  };

  return (
    <div className="container">
      <form onSubmit={(e) => e.preventDefault()}>
        <h1>Pesquisa de Veículo</h1>

        {/* Campo para o usuário informar o código FIPE */}
        <input
          placeholder="Digite o código FIPE"
          name="codigoFipe"
          type="text"
          value={codigoFipe}
          onChange={(e) => setCodigoFipe(e.target.value)}
        />
        <button type="button" onClick={fetchVeiculoDetalhes}>Buscar</button>
      </form>

      {/* Exibe os detalhes do veículo se disponíveis */}
      {veiculoDetalhes && (
        <div className="card">
          <p><strong>Valor:</strong> {veiculoDetalhes.valor}</p>
          <p><strong>Marca:</strong> {veiculoDetalhes.marca}</p>
          <p><strong>Modelo:</strong> {veiculoDetalhes.modelo}</p>
          <p><strong>Ano Modelo:</strong> {veiculoDetalhes.anoModelo}</p>
          <p><strong>Combustível:</strong> {veiculoDetalhes.combustivel}</p>
          <p><strong>Código FIPE:</strong> {veiculoDetalhes.codigoFipe}</p>
          <p><strong>Mês de Referência:</strong> {veiculoDetalhes.mesReferencia}</p>
          <p><strong>Tipo do Veículo:</strong> {veiculoDetalhes.tipoVeiculo}</p>
          <p><strong>Sigla Combustível:</strong> {veiculoDetalhes.siglaCombustivel}</p>
          <p><strong>Data da Consulta:</strong> {veiculoDetalhes.dataConsulta}</p>
        </div>
      )}
    </div>
  );
}

export default Home;
